# WireShark-Profiles
Wireshark Profiles - Containing DFilters, CFilters (BPF Syntax), Coloring Rules, Preferences, IOGraphs

# Example of profile folder contents:

adamdawson@-XXXX WireShark Profiles % cd "Better Default + Packet Diagram"
adamdawson@-XXXX Better Default + Packet Diagram % ls -halt
total 536
drwxr-xr-x  94 adamdawson  staff   2.9K 16 Jun 09:21 ..
drwxr-xr-x@ 13 adamdawson  staff   416B 16 Jun 09:14 .
-rw-rw-r--@  1 adamdawson  staff   4.1K 18 May 06:51 recent
-rw-rw-r--@  1 adamdawson  staff   240B 18 May 06:51 decode_as_entries
-rw-rw-r--@  1 adamdawson  staff   2.9K 18 May 06:51 dfilter_buttons
-rw-rw-r--@  1 adamdawson  staff   221K 18 May 06:51 preferences
-rw-rw-r--@  1 adamdawson  staff   1.1K 10 Jan 14:17 netsci.txt
-rw-rw-r--@  1 adamdawson  staff   1.9K 15 Nov  2021 cfilters
-rw-rw-r--@  1 adamdawson  staff   1.6K 11 Mar  2021 colorfilters
-rw-rw-r--@  1 adamdawson  staff    79B 11 Mar  2021 dfilter_macros
-rw-rw-r--@  1 adamdawson  staff   934B 11 Mar  2021 dfilters
-rw-rw-r--@  1 adamdawson  staff   419B 11 Mar  2021 hosts
-rw-rw-r--@  1 adamdawson  staff   783B 11 Mar  2021 io_graphs

## Wireshark Best Practices for Packet Heads
#** Remember to setup default packet capture type as PCAP-NG (Next-Generation) Format which are backwards compatible and also store them as trace files which includes packet comments** 
#** Remember to setup default Packet Capture Location Folder for ease of saving traces
PCAP-NG (Next-Gen) 
#** MaxMind Geo-IP DB's

## Wireshark Best Practices for System Performance

## Differences between CFilters (Capture Filters) and DFilters (Display Filters)
#** Both use the BPF (Berkley Packet Filter) Syntax 
